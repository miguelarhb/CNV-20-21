export CLASSPATH="$CLASSPATH:/home/ec2-user/cnv/BIT:/home/ec2-user/cnv/BIT/samples:./"
