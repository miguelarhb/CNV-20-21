export _JAVA_OPTIONS="-XX:-UseSplitVerifier "$_JAVA_OPTIONS
